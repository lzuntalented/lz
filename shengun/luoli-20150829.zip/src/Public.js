PublicData = {
	SCREEN_HEIGHT : 0,
    SCREEN_WIDTH  : 0
}
