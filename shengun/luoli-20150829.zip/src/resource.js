var res = {
    HelloWorld_png : "res/HelloWorld.png",
    CloseNormal_png : "res/CloseNormal.png",
    CloseSelected_png : "res/CloseSelected.png",
    Back_1_png : "res/back_1.png",
    Background2_png : "res/background2.png",
    Start_normal_png : "res/start_normal.png",
    Start_select_png : "res/start_select.png",
    Stick_black_png : "res/stick_black.png",
    Walk_png : "res/walk.plist"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}