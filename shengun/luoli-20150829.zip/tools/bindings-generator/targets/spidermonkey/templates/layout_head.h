\#ifndef __${prefix}_h__
\#define __${prefix}_h__

\#include "jsapi.h"
\#include "jsfriendapi.h"

