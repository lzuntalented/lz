#set generator = $current_class.generator
JSClass  *jsb_${current_class.underlined_class_name}_class;
JSObject *jsb_${current_class.underlined_class_name}_prototype;

