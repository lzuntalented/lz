do {
	// Lambda binding for lua is not supported.
	assert(false);
} while(0)
